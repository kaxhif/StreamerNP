#pragma once

#include "resource.h"

#define BUFFER_SIZE 1024

//typedef struct _OVERLAPPED {
//	DWORD  Internal;     // [out] Error code
//	DWORD  InternalHigh; // [out] Number of bytes transferred
//	DWORD  Offset;       // [in]  Low  32-bit file offset
//	DWORD  OffsetHigh;   // [in]  High 32-bit file offset
//	HANDLE hEvent;       // [in]  Event handle or data
//} OVERLAPPED;

void PipeOperations();
int WriteString(HANDLE hPipe, CString message, BOOL async=FALSE);
BOOL ReadString(HANDLE hPipe, CString*, BOOL async = FALSE);
//void ProcessMenu(CString menu);
