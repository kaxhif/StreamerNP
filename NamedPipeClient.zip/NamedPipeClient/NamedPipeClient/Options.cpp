#include "stdafx.h"
#include "Options.h"


COption::COption()
{
	m_optionId=0;
	m_optionCode="";
	m_optionString="";
}

COption::COption(int optId, CString optCode, CString optStr)
{
	m_optionId = optId;
	m_optionCode = optCode;
	m_optionString = optStr;
}

COption::~COption()
{
}

void COption::SetOptionId(int optId)
{
	m_optionId = optId;
}

int COption::GetOptionId()
{
	return m_optionId;
}

void COption::SetOptionCode(CString optCode)
{
	m_optionCode = optCode;
}

CString COption::GetOptionCode()
{
	return m_optionCode;
}

void COption::SetOptionString(CString optStr)
{
	m_optionString = optStr;
}

CString COption::GetOptionString()
{
	return m_optionString;
}

CString COption::GetPrint()
{
	CString strPrintOpt = "";
	strPrintOpt.Format("%d. %s", m_optionId, m_optionString);
	return strPrintOpt;
}