// NamedPipeClient.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "NamedPipeClient.h"
#include "Options.h"
#include "OptionsMenu.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// The one and only application object

CWinApp theApp;

using namespace std;

int main()
{
	int nRetCode = 0;

	HMODULE hModule = ::GetModuleHandle(nullptr);

	if (hModule != nullptr)
	{
		// initialize MFC and print and error on failure
		if (!AfxWinInit(hModule, nullptr, ::GetCommandLine(), 0))
		{
			// TODO: change error code to suit your needs
			wprintf(L"Fatal Error: MFC initialization failed\n");
			nRetCode = 1;
		}
		else
		{
			// TODO: code your application's behavior here.
			wprintf(L"Named Pipe Client\n");
			PipeOperations();
		}
	}
	else
	{
		// TODO: change error code to suit your needs
		wprintf(L"Fatal Error: GetModuleHandle failed\n");
		nRetCode = 1;
	}

	return nRetCode;
}

void PipeOperations()
{
	int attempts = 0;
	int maxAttempts = 30;
	CString message = "";

	HANDLE hPipe= INVALID_HANDLE_VALUE, hAsyncPipe= INVALID_HANDLE_VALUE;
	CString strPipeName = "\\\\.\\Pipe\\NamedPipe";

	while (attempts < maxAttempts)
	{
		hPipe = CreateFile(
			strPipeName.GetBuffer(0),   // pipe name 
			GENERIC_READ |  // read and write access 
			GENERIC_WRITE,
			0,              // no sharing 
			NULL,           // default security attributes
			OPEN_EXISTING,  // opens existing pipe 
			0,              // default attributes 
			NULL);          // no template file 
		if (INVALID_HANDLE_VALUE == hPipe)
		{
			message.Format("Error occurred while connecting to the Named Pipe Server: attempt:#%d", attempts + 1);
			OutputDebugString(message);
			OutputDebugString("\r\n");

			Sleep(1000);//wait for a second and then re-try
			attempts++;
		}
		else
			break;
		//strSessionPipeName.ReleaseBuffer();
	}

	attempts = 0;
	while (attempts < maxAttempts)
	{
		hAsyncPipe = CreateFile(
			strPipeName.GetBuffer(0),   // pipe name 
			GENERIC_READ |  // read and write access 
			GENERIC_WRITE,
			0,              // no sharing 
			NULL,           // default security attributes
			OPEN_EXISTING,  // opens existing pipe 
			FILE_FLAG_OVERLAPPED,  // default attributes for async communication
			NULL);          // no template file 
		if (INVALID_HANDLE_VALUE == hAsyncPipe)
		{
			message.Format("Error occurred while connecting to the Named Pipe Server Async mode: attempt:#%d", attempts + 1);
			OutputDebugString(message);
			OutputDebugString("\r\n");

			Sleep(1000);//wait for a second and then re-try
			attempts++;
		}
		else
			break;
	}
	strPipeName.ReleaseBuffer();
	if (INVALID_HANDLE_VALUE == hPipe || INVALID_HANDLE_VALUE == hAsyncPipe)
	{
		message = "Error occurred while connecting to the Named Pipe Server ";
		printf(message);
		printf("\r\n");
	}
	else
	{
		//Main Client Loop
		bool bExit = false;
		CString optionCode = "";
		while (!bExit)
		{
			//Step1: Get current Menu from Server
			if (optionCode.IsEmpty())
				WriteString(hPipe, "GetMenu");
			else
				WriteString(hPipe, optionCode);
			printf("Client: GetMenu");
			printf("\r\n");
			CString strMenu= "";
			ReadString(hPipe, &strMenu);
			
			//Step2: Process Menu
			//ProcessMenu(strMenu);
			COptionsMenu menu(strMenu);

			//Step2a: Print Menu
			int nOpt = menu.GetNumberOfOptions();
			if (nOpt > 0)
			{
				for (int i = 0; i < nOpt; i++)
				{
					printf(menu.GetOptionStr(i));
					printf("\r\n");
				}
				//Step3: Get Input from User
				int optId;
				cin >> optId;
				//Step4: Send command to Server
				CString optCode = menu.GetOptCodeById(optId);
				if (optCode.IsEmpty() == false)
				{
					optionCode = optCode;
					if (optId == 4)
					{
						WriteString(hAsyncPipe, optCode, TRUE);
						CString strMsg="";
						ReadString(hAsyncPipe, &strMsg, TRUE);
						printf(strMsg);
						printf("\r\n");
						optionCode = "";
					}

					//WriteString(hPipe, optCode);
					//CString strMsg;
					//ReadString(hPipe, &strMsg);
					//printf("strmsg:");
					//printf(strMsg);
					//printf("\r\n");
				}
				else
				{
					printf("Invalid Option\r\n");
					optionCode = "";
				}
			}
			else
			{
				printf("Received from server: ");
				printf(strMenu);
				printf("\r\n");

				optionCode = "";
			}
		}
	}
}

int WriteString(HANDLE hPipe, CString message, BOOL async)
{
	DWORD cbBytes;
	DWORD len = message.GetLength();

	//Send the message to server
	//if (async)
	//{
	//	BOOL bResult = WriteFile(
	//		hPipe,                // handle to pipe 
	//		message.GetBuffer(0), // buffer to write from 
	//		len,                  // number of bytes to write, include the NULL
	//		&cbBytes,             // number of bytes written 
	//		NULL);                // not overlapped I/O 

	//	if ((!bResult) || ((DWORD)(len) != cbBytes))
	//	{

	//		CString message = "Error occurred while writing to Named Pipe Server";

	//		printf(message);
	//	}
	//	return (len + 2);
	//}
	//else
	{
		BOOL bResult = WriteFile(
			hPipe,                // handle to pipe 
			message.GetBuffer(0), // buffer to write from 
			len,                  // number of bytes to write, include the NULL
			&cbBytes,             // number of bytes written 
			NULL);                // not overlapped I/O 

		if ((!bResult) || ((DWORD)(len) != cbBytes))
		{

			CString message = "Error occurred while writing to Named Pipe Server";

			printf(message);
		}
		return (len + 2);
	}
}

BOOL ReadString(HANDLE hPipe, CString* message, BOOL async)
{
	char szBuffer[BUFFER_SIZE];
	DWORD cbBytes;
	DWORD len = 0;
	BOOL bResult = FALSE;
	if (async)
	{
		OVERLAPPED overlapped;
		ZeroMemory(&overlapped, sizeof(OVERLAPPED));
		overlapped.hEvent = CreateEvent(nullptr, TRUE, FALSE, nullptr);

		bResult = ReadFile(
			hPipe,                // handle to pipe 
			szBuffer,             // buffer to receive data 
			BUFFER_SIZE - 1,        // size of buffer 
			&cbBytes,             // number of bytes read 
			&overlapped);                // overlapped I/O 
								  //message(szBuffer, cbBytes);
		if (bResult == false)
		{
			if (GetLastError() != ERROR_IO_PENDING)
			{
				// The function call failed. ToDo: recovery.
				printf("Failed to async read \r\n");
				return ERROR_READ_FAULT;
			}
			else
			{
				// TODO: add a timeout...
				bResult = GetOverlappedResult(hPipe, &overlapped, &cbBytes, TRUE);
			}

		}
		*message = CString(szBuffer, cbBytes);
	}
	else
	{
		bResult = ReadFile(
			hPipe,                // handle to pipe 
			szBuffer,             // buffer to receive data 
			BUFFER_SIZE - 1,        // size of buffer 
			&cbBytes,             // number of bytes read 
			NULL);                // not overlapped I/O 
								  //message(szBuffer, cbBytes);
		*message = CString(szBuffer, cbBytes);

	}
	return bResult;
}
