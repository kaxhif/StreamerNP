#pragma once
class COption
{
public:
	COption();
	COption(int optId, CString optCode, CString optStr);
	~COption();
	
	//Getter/Setters
	void SetOptionId(int);
	int GetOptionId();

	void SetOptionCode(CString);
	CString GetOptionCode();

	void SetOptionString(CString);
	CString GetOptionString();

	CString GetPrint();
private:
	int m_optionId;
	CString m_optionCode;
	CString m_optionString;
};

