#pragma once
#include "Options.h"
#include <vector>

class COptionsMenu
{
public:
	COptionsMenu(CString menu);
	~COptionsMenu();
	bool FindOptionById(int, COption*);
	CString COptionsMenu::GetOptCodeById(int optId);
	CString GetOptionStr(int ind);
	int GetNumberOfOptions();
	
private:
	CString m_menu;
	std::vector<COption> m_menuOptions; 
	
	void ProcessMenu();
	void ProcessMenuOption(CString token);
};

