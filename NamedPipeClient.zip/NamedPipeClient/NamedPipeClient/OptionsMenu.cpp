#include "stdafx.h"
#include "OptionsMenu.h"

#define OPTION_TOKEN_ID 0
#define OPTION_TOKEN_STRING 1
#define OPTION_TOKEN_CODE 2

COptionsMenu::COptionsMenu(CString menu)
{
	m_menu = menu;
	ProcessMenu();
}


COptionsMenu::~COptionsMenu()
{
}

//Menu string will be like:
//OptionId, Option String, Option Code
//1,Math Class, 101
//2,String Class, 102
//3,Server Version, 103
//4,Server Time, 104
//5,Exit, 105
void COptionsMenu::ProcessMenu()
{
	int curPos = 0;
	CString tMenu = m_menu;
	CString token = tMenu.Tokenize(_T("\r\n"), curPos);
	while (token != _T(""))
	{
		ProcessMenuOption(token);
		token = tMenu.Tokenize(_T("\r\n"), curPos);
	}
}

void COptionsMenu::ProcessMenuOption(CString optionStr)
{
	int curPos = 0;
	int curTok = 0;
	CString token = optionStr.Tokenize(_T(","), curPos);
	bool bOptId = false, bOptStr = false, bOptCode = false;
	COption opt;
	while (token != _T(""))
	{
		switch (curTok)
		{
		case OPTION_TOKEN_ID:
			opt.SetOptionId(atoi(token));
			bOptId = true;
			break;
		case OPTION_TOKEN_STRING:
			opt.SetOptionString(token.Trim());
			bOptStr= true; 
			break;
		case OPTION_TOKEN_CODE:
			opt.SetOptionCode(token.Trim());
			bOptCode = true; 
			break;
		default:
			break;
		}
		token = optionStr.Tokenize(_T(","), curPos);
		curTok++;
	}
	if (bOptId && bOptStr && bOptCode)
		m_menuOptions.push_back(opt);
}
bool COptionsMenu::FindOptionById(int optId, COption* opt)
{
	bool retVal = false;
	for (int i = 0; i < static_cast<int>(m_menuOptions.size()); i++)
	{
		if (m_menuOptions.at(i).GetOptionId() == optId)
		{
			opt = &m_menuOptions[i];
			retVal = true;
			break;
		}
	}
	return retVal;
}

CString COptionsMenu::GetOptCodeById(int optId)
{
	CString retStr = "";
	for (int i = 0; i < static_cast<int>(m_menuOptions.size()); i++)
	{
		if (m_menuOptions.at(i).GetOptionId() == optId)
		{
			retStr = m_menuOptions[i].GetOptionCode();
			break;
		}
	}
	return retStr;
}

CString COptionsMenu::GetOptionStr(int ind)
{
	CString retStr = "";
	if (ind >= 0 && ind < static_cast<int>(m_menuOptions.size()))
		retStr = m_menuOptions[ind].GetPrint();
	return retStr;
}

int COptionsMenu::GetNumberOfOptions()
{
	return static_cast<int>(m_menuOptions.size());
}