#pragma once
class CMathClass
{
private:
	int a;
	int b;
	int result;
public:
	CMathClass();
	~CMathClass();

	void SetA(int _a);
	int GetA();
	void SetB(int _b);
	int GetB();
	int GetResult();
	int Add();
	int Subtract();
	int Divide();
	int Multiply();
	CString Serialize();

};

