#include "stdafx.h"
#include "StringClass.h"


CStringClass::CStringClass()
{
	strA = "";
	strB = "";
}


CStringClass::~CStringClass()
{
}

CString CStringClass::GetA()
{
	return strA;
}

void CStringClass::SetA(CString _a)
{
	this->strA = _a;
}
CString CStringClass::GetB()
{
	return strB;
}

void CStringClass::SetB(CString _b)
{
	this->strB = _b;
}

CString CStringClass::Concat()
{
	return strA + strB;
}

bool CStringClass::FindBinA()
{
	bool retVal = strA.Find(strB, 0);
	return retVal;
}

CString CStringClass::ToUpper()
{
	return strA.MakeUpper();
}

CString CStringClass::ToLower()
{
	return strA.MakeLower();
}

CString CStringClass::Serialize()
{
	//size_t buffer_size = sizeof(int) + strA.GetLength() + sizeof(int) + strB.GetLength() + 1;
	//char *buffer = new char[buffer_size];
	//char *p = buffer;
	//sprintf(buffer, "%d%s%d%s", strA.GetLength(), strA.GetBuffer(), strB.GetLength(), strB.GetBuffer());
	/**(int*)p = strA.GetLength();  p += sizeof(int);
	memcpy(p, strA.GetBuffer(), strA.GetLength());  p += strA.GetLength();
	strA.ReleaseBuffer();

	*(int*)p = strB.GetLength();  p += sizeof(int);
	memcpy(p, strB.GetBuffer(), strB.GetLength());  p += strB.GetLength();
	strB.ReleaseBuffer();*/

	CString strObj;
	strObj.Format("Serialized Object: %d %s %d %s", strA.GetLength(), strA.GetBuffer(), strB.GetLength(), strB.GetBuffer());
	strA.ReleaseBuffer();
	strB.ReleaseBuffer();
	return strObj;
}