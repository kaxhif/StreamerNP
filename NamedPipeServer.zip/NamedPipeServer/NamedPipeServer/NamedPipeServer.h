#pragma once

#include "resource.h"

#define BUFFER_SIZE 1024

const CString MENU1 = "1, Math Class, 101 \r\n2, String Class, 102 \r\n3, Server Version, 103 \r\n4, Server Time, 104 \r\n5, Exit, 105 \r\n";
const CString MENU101 = "1, Add, 10101 \r\n2, Subtract, 10102 \r\n3, Multiply, 10103 \r\n4, Divide, 10104 \r\n5, Object, 10105 \r\n6, Return to Top Menu, 10106 \r\n";
const CString MENU102 = "1, Concat, 10201 \r\n2, Find String, 10202 \r\n3, To Upper, 10203 \r\n4, To Lower, 10204 \r\n5, Object, 10205 \r\n6, Return to Top Menu, 10106 \r\n";
const CString MENU103 = "0, Server Version 1.0,10300\r\n 1, Return to Top Menu, 10301 \r\n";
const CString MENU104 = "0, Server Time ,10400\r\n 1, Return to Top Menu, 10401 \r\n";	//Async Call
const CString MENU105 = "0, Exit, 10500 \r\n";

int PipeOperations();
DWORD WINAPI InstanceThread(LPVOID lpvParam);
int WriteString(HANDLE hPipe, CString message, BOOL async = FALSE);
BOOL ReadString(HANDLE hPipe, CString*);
