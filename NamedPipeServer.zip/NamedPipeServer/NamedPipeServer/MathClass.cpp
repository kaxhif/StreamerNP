#include "stdafx.h"
#include "MathClass.h"


CMathClass::CMathClass()
{
	a = 0;
	b = 0;
	result = 0;
}


CMathClass::~CMathClass()
{
}

void CMathClass::SetA(int _a)
{
	this->a = _a;
}

int CMathClass::GetA()
{
	return a;
}

void CMathClass::SetB(int _b)
{
	this->b = _b;
}

int CMathClass::GetB()
{
	return b;
}

int CMathClass::GetResult()
{
	return result;
}

int CMathClass::Add()
{
	result = a + b;
	return result;
}

int CMathClass::Subtract()
{
	result = a - b;
	return result;
}

int CMathClass::Divide()
{
	if (b != 0)
		result = a / b;
	else
		result = -1;	//just to avoid division by 0
	return result;
}

int CMathClass::Multiply()
{
	result = a * b;
	return result;
}

CString CMathClass::Serialize()
{
	size_t buffer_size = sizeof(a) + sizeof(b) + sizeof(result);
	char *buffer = new char[buffer_size];
	char *p = buffer;
	*(int*)p = a;  p += sizeof(int);
	*(int*)p = b;  p += sizeof(int);
	*(int*)p = result;
	CString strObj;
	strObj.Format("Serialized Object:%s", buffer);
	delete[] buffer;
	return strObj;
}
