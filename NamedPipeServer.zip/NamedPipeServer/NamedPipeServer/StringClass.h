#pragma once
class CStringClass
{
	CString strA;
	CString strB;
public:
	CStringClass();
	~CStringClass();

	CString GetA();
	void SetA(CString);

	CString GetB();
	void SetB(CString);
	CString Concat();
	bool FindBinA();
	CString ToUpper();
	CString ToLower();
	CString Serialize();
};

