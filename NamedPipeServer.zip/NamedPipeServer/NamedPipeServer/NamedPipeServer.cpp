// NamedPipeServer.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "NamedPipeServer.h"
#include "MathClass.h"
#include "StringClass.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// The one and only application object

CWinApp theApp;

using namespace std;

int main()
{
    int nRetCode = 0;

    HMODULE hModule = ::GetModuleHandle(nullptr);

    if (hModule != nullptr)
    {
        // initialize MFC and print and error on failure
        if (!AfxWinInit(hModule, nullptr, ::GetCommandLine(), 0))
        {
            // TODO: change error code to suit your needs
            printf("Fatal Error: MFC initialization failed\n");
            nRetCode = 1;
        }
        else
        {
            // TODO: code your application's behavior here.
			printf("Named Pipe Server\n");
			PipeOperations();
        }
    }
    else
    {
        // TODO: change error code to suit your needs
        printf("Fatal Error: GetModuleHandle failed\n");
        nRetCode = 1;
    }

    return nRetCode;
}

int PipeOperations()
{
	BOOL   fConnected = FALSE;
	DWORD  dwThreadId = 0;
	HANDLE hPipe = INVALID_HANDLE_VALUE, hThread = NULL;
	CString pipeNaem = TEXT("\\\\.\\pipe\\NamedPipe");

	// The main loop creates an instance of the named pipe and 
	// then waits for a client to connect to it. When the client 
	// connects, a thread is created to handle communications 
	// with that client, and this loop is free to wait for the
	// next client connect request. It is an infinite loop.

	for (;;)
	{
		hPipe = CreateNamedPipe(
			pipeNaem,             // pipe name 
			PIPE_ACCESS_DUPLEX |       // read/write access 
			FILE_FLAG_OVERLAPPED,      //overlapped mode
			PIPE_TYPE_MESSAGE |       // message type pipe 
			PIPE_READMODE_MESSAGE |   // message-read mode 
			PIPE_WAIT,                // blocking mode 
			PIPE_UNLIMITED_INSTANCES, // max. instances  
			BUFFER_SIZE,                  // output buffer size 
			BUFFER_SIZE,                  // input buffer size 
			0,                        // client time-out 
			NULL);                    // default security attribute 

		if (hPipe == INVALID_HANDLE_VALUE)
		{
			printf("CreateNamedPipe failed, GLE=%d.\n", GetLastError());
			return -1;
		}

		// Wait for the client to connect; if it succeeds, 
		// the function returns a nonzero value. If the function
		// returns zero, GetLastError returns ERROR_PIPE_CONNECTED. 

		fConnected = ConnectNamedPipe(hPipe, NULL) ?
			TRUE : (GetLastError() == ERROR_PIPE_CONNECTED);

		if (fConnected)
		{
			printf("Client connected, creating a processing thread.\n");

			// Create a thread for this client. 
			hThread = CreateThread(
				NULL,              // no security attribute 
				0,                 // default stack size 
				InstanceThread,    // thread proc
				(LPVOID)hPipe,    // thread parameter 
				0,                 // not suspended 
				&dwThreadId);      // returns thread ID 

			if (hThread == NULL)
			{
				_tprintf(TEXT("CreateThread failed, GLE=%d.\n"), GetLastError());
				return -1;
			}
			else CloseHandle(hThread);
		}
		else
			// The client could not connect, so close the pipe. 
			CloseHandle(hPipe);
	}
}

DWORD WINAPI InstanceThread(LPVOID lpvParam)
// This routine is a thread processing function to read from and reply to a client
// via the open pipe connection passed from the main loop.
{
	DWORD cbBytesRead = 0, cbReplyBytes = 0, cbWritten = 0;
	BOOL fSuccess = FALSE;
	HANDLE hPipe = NULL;

	if (lpvParam == NULL)
	{
		printf("\nERROR - Pipe Server Failure:\n");
		printf("   InstanceThread got an unexpected NULL value in lpvParam.\n");
		printf("   InstanceThread exitting.\n");
		return (DWORD)-1;
	}

	// Print verbose messages. In production code, this should be for debugging only.
	printf("InstanceThread created, receiving and processing messages.\n");

	// The thread's parameter is a handle to a pipe object instance. 

	hPipe = (HANDLE)lpvParam;
	
	CMathClass mc;
	mc.SetA(5);
	mc.SetB(7);

	CStringClass sc;
	sc.SetA("Hello World!");
	sc.SetB("World");

	// Loop until done reading
	while (1)
	{
		CString strMessage;
		BOOL bRead = ReadString(hPipe, &strMessage);
		if (bRead)
		{
			printf("Server: read" + strMessage);
			printf("\r\n");
			if (strMessage == "GetMenu")
			{
				WriteString(hPipe, MENU1);
				printf("MENU1 \r\n");
			}
			else if (strMessage == "101")
			{
				WriteString(hPipe, MENU101);
				printf("MENU 101\r\n");
			}
			else if (strMessage == "10101")
			{
				mc.Add(); 
				CString strMC;
				strMC.Format("%d + %d = %d", mc.GetA(), mc.GetB(), mc.GetResult());
				WriteString(hPipe, strMC);
				//printf("MENU 101\r\n");
			}
			else if (strMessage == "10102")
			{
				mc.Subtract();
				CString strMC;
				strMC.Format("%d - %d = %d", mc.GetA(), mc.GetB(), mc.GetResult());
				WriteString(hPipe, strMC);
			}
			else if (strMessage == "10103")
			{
				mc.Multiply();
				CString strMC;
				strMC.Format("%d * %d = %d", mc.GetA(), mc.GetB(), mc.GetResult());
				WriteString(hPipe, strMC);
			}
			else if (strMessage == "10104")
			{
				mc.Divide();
				CString strMC;
				strMC.Format("%d / %d = %d", mc.GetA(), mc.GetB(), mc.GetResult());
				WriteString(hPipe, strMC);
			}
			else if (strMessage == "10105")
			{
				WriteString(hPipe, mc.Serialize());
			}
			else if (strMessage == "10106")
			{
				WriteString(hPipe, MENU1);
			}
			else if (strMessage == "102")
			{
				WriteString(hPipe, MENU102);
				printf("MENU 101\r\n");
			}
			else if (strMessage == "10201")
			{
				WriteString(hPipe, sc.Concat());
			}
			else if (strMessage == "10202")
			{
				CString strFound = "";
				if (sc.FindBinA())
					strFound = "Yes";
				else
				{
					strFound = "No";
				}
				WriteString(hPipe, strFound);
			}
			else if (strMessage == "10203")
			{
				WriteString(hPipe, sc.ToUpper());
			}
			else if (strMessage == "10204")
			{
				WriteString(hPipe, sc.ToLower());
			}
			else if (strMessage == "10205")
			{
				WriteString(hPipe, sc.Serialize());
			}
			else if (strMessage == "10206")
			{
				WriteString(hPipe, MENU1);
			}
			else if (strMessage == "103")
			{
				WriteString(hPipe, MENU103);
				printf("MENU 101\r\n");
			}
			else if (strMessage == "10301")
			{
				WriteString(hPipe, MENU1);
			}
			else if (strMessage == "104")
			{
				int nRandWait = rand() % 10;
				Sleep(nRandWait * 1000);
				CString strTimeMsg;
				COleDateTime dtNow = COleDateTime::GetCurrentTime();
				strTimeMsg.Format("Server Time: %2d:%2d:%2d\r\n", dtNow.GetHour(), dtNow.GetMinute(), dtNow.GetSecond());
				WriteString(hPipe, strTimeMsg);
				printf("MENU 101\r\n");
			}
			else if (strMessage == "10401")
			{
				WriteString(hPipe, MENU1);
			}
			else if (strMessage == "105")
			{
				break;
			}
			else
			{
				printf(strMessage);
				printf("  invalid option");
				printf("\r\n");
			}
		}
		else
		{
			printf("Client disconnected\r\n");
			break;
		}
	}

	// Flush the pipe to allow the client to read the pipe's contents 
	// before disconnecting. Then disconnect the pipe, and close the 
	// handle to this pipe instance. 

	FlushFileBuffers(hPipe);
	DisconnectNamedPipe(hPipe);
	CloseHandle(hPipe);

	printf("InstanceThread exitting.\n");
	return 1;
}

int WriteString(HANDLE hPipe, CString message, BOOL async )
{
	DWORD cbBytes;
	DWORD len = message.GetLength();
	BOOL bResult;

	if (async)
	{
		OVERLAPPED ovp;
		ZeroMemory(&ovp, sizeof(OVERLAPPED));
		ovp.hEvent = CreateEvent(nullptr, TRUE, FALSE, nullptr);
		bResult = WriteFile(
			hPipe,                // handle to pipe 
			message.GetBuffer(0), // buffer to write from 
			len,                  // number of bytes to write, include the NULL
			&cbBytes,             // number of bytes written 
			&ovp);                // overlapped I/O 

		if ((!bResult) || ((DWORD)(len) != cbBytes))
		{
			DWORD dwErr = GetLastError();
			if (!bResult && (dwErr == ERROR_IO_PENDING))
			{
				bResult = GetOverlappedResult(
					hPipe, // handle to pipe 
					&ovp, // OVERLAPPED structure 
					&len,            // bytes transferred 
					TRUE);            // do not wait 
				CString message = "Async write success\r\n";
				printf(message);
			}
			else
			{
				CString message = "Error occurred while writing to Named Pipe Server";
				printf(message);
			}
		}
	}
	else
	{
		bResult = WriteFile(
			hPipe,                // handle to pipe 
			message.GetBuffer(0), // buffer to write from 
			len,                  // number of bytes to write, include the NULL
			&cbBytes,             // number of bytes written 
			NULL);                // not overlapped I/O 

		if ((!bResult) || ((DWORD)(len) != cbBytes))
		{

			CString message = "Error occurred while writing to Named Pipe Server";

			printf(message);
		}
	}
	return (len + 2);
}

BOOL ReadString(HANDLE hPipe, CString* message)
{
	char szBuffer[BUFFER_SIZE];
	DWORD cbBytes;
	DWORD len = 0;

	//BOOL bResult = ReadFile(
	//	hPipe,                // handle to pipe 
	//	szBuffer,             // buffer to receive data 
	//	BUFFER_SIZE - 1,        // size of buffer 
	//	&cbBytes,             // number of bytes read 
	//	NULL);                // not overlapped I/O 
	//len = szBuffer[0] * 256;

	//bResult = ReadFile(
	//	hPipe,                // handle to pipe 
	//	szBuffer,             // buffer to receive data 
	//	BUFFER_SIZE - 1,        // size of buffer 
	//	&cbBytes,             // number of bytes read 
	//	NULL);                // not overlapped I/O 

	BOOL bResult = ReadFile(
		hPipe,                // handle to pipe 
		szBuffer,             // buffer to receive data 
		BUFFER_SIZE - 1,        // size of buffer 
		&cbBytes,             // number of bytes read 
		NULL);                // not overlapped I/O 
							  //message(szBuffer, cbBytes);
	*message = CString(szBuffer, cbBytes);
	return bResult;
}
